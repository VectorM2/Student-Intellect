---
title: Broadcast
categories:
  - Communications
tags:
  - radio
  - "radio wave"
  - amplify
  - wavelength
---
