---
title: Border middle
categories:
  - UI and keyboard
tags:
  - borders
---
