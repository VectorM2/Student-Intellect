---
title: Building gear
categories:
  - Buildings
tags:
  - company
  - enterprise
  - organization
  - office
  - business
---
